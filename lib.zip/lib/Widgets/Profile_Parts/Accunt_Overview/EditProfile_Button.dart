import 'package:flutter/material.dart';

class EditProfileButton
    extends StatelessWidget {

  final VoidCallback onPressed;

  const EditProfileButton({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {

    return SizedBox(
      width: 230,
      height: 90,

      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              const Color(0xFF3F8A73),

          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(16),
          ),
        ),

        onPressed: onPressed,

        icon: const Icon(
          Icons.edit,
          color: Colors.white,
          size: 30,
        ),

        label: const Text(
          "Redigera",

          style: TextStyle(
            color: Colors.white,
            fontSize: 30,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}