import 'package:flutter/material.dart';
import 'package:imat_repo/Widgets/Profile_Parts/Header/CloseProfile_Button.dart';
import 'package:imat_repo/Widgets/Profile_Parts/Header/LogoutButton%20.dart';
import 'package:imat_repo/Widgets/Profile_Parts/Profile_Title.dart';

class ProfileHeader extends StatelessWidget {
  const ProfileHeader({super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      width: double.infinity,
      color: Colors.white,

      padding: const EdgeInsets.symmetric(
        horizontal: 60,
        vertical: 40,
      ),

      child: Row(
        children: [

          const CloseProfileButton(),

          const SizedBox(width: 24),

          const ProfileTitle(),

          const Spacer(),

          LogoutButton(),
        ],
      ),
    );
  }
}