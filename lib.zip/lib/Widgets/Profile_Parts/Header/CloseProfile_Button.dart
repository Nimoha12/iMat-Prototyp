import 'package:flutter/material.dart';

class CloseProfileButton
    extends StatelessWidget {

  const CloseProfileButton({
    super.key,
  });

  @override
  Widget build(BuildContext context) {

    return IconButton(
      onPressed: () {

        Navigator.pop(context);

      },

      icon: Container(
        width: 64,
        height: 64,

        decoration: BoxDecoration(
          shape: BoxShape.circle,

          border: Border.all(
            color: Colors.black54,
            width: 2,
          ),
        ),

        child: const Icon(
          Icons.close,
          size: 34,
        ),
      ),
    );
  }
}