import 'package:flutter/material.dart';
import 'package:imat_repo/Pages/home_page.dart';
import 'package:imat_repo/model/AuthState.dart';

import 'package:provider/provider.dart';


class LogoutButton
    extends StatelessWidget {

  const LogoutButton({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 190,
      height: 90,

      child: OutlinedButton(
        onPressed: () {
          
        context.read<AuthState>().logout();
          //////////////////////////////////////////////////////
          /// LOG OUT
          //////////////////////////////////////////////////////

          Navigator.pushAndRemoveUntil(
            context,

            MaterialPageRoute(
              builder: (context) =>
                  const HomePage(),
            ),

            (route) => false,
            
          );
        },

        style: OutlinedButton.styleFrom(
          side: const BorderSide(width: 3),

          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(16),
          ),
        ),

        child: const Text(
          "Logga ut",

          style: TextStyle(
            fontSize: 32,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}